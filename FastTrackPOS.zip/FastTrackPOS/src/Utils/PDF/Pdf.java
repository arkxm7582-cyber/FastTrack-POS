/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils.PDF;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;

public class Pdf {
        public static void generatePdf(String filename, String content ) {
            Document document = new Document();
            try {
                PdfWriter.getInstance(document, new FileOutputStream("./pdf/" + filename));
                document.open();
                document.add(new Paragraph(content));
                document.close();
                System.out.println("PDF created successfully: " + filename);
            } catch (DocumentException | IOException e) {
                e.printStackTrace();
            }
        }

}
