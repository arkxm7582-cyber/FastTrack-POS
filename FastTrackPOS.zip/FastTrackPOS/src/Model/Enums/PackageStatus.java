/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.Enums;

public enum PackageStatus {
    ORDER_PLACED,
    PICKED_UP_BY_COURIER,
    AT_ORIGIN_WAREHOUSE,
    IN_TRANSIT_TO_DESTINATION,
    AT_DESTINATION_WAREHOUSE,
    OUT_FOR_DELIVERY,
    DELIVERED_TO_RECIPIENT
}
